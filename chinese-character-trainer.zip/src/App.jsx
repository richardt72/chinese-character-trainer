
import { useState } from "react";

const characters = [
  { character: "我", meaning: "I", pinyin: "wǒ" },
  { character: "你", meaning: "you", pinyin: "nǐ" },
  { character: "他", meaning: "he", pinyin: "tā" },
  { character: "她", meaning: "she", pinyin: "tā" },
  { character: "是", meaning: "is/are/am", pinyin: "shì" },
  { character: "的", meaning: "of", pinyin: "de" },
  { character: "了", meaning: "past particle", pinyin: "le" },
  { character: "不", meaning: "not", pinyin: "bù" },
  { character: "在", meaning: "at/in/on", pinyin: "zài" },
  { character: "有", meaning: "have", pinyin: "yǒu" },
  { character: "和", meaning: "and", pinyin: "hé" },
  { character: "人", meaning: "person", pinyin: "rén" },
  { character: "这", meaning: "this", pinyin: "zhè" },
  { character: "中", meaning: "middle", pinyin: "zhōng" },
  { character: "大", meaning: "big", pinyin: "dà" },
  { character: "为", meaning: "for", pinyin: "wèi" },
  { character: "上", meaning: "up", pinyin: "shàng" },
  { character: "个", meaning: "measure word", pinyin: "gè" },
  { character: "国", meaning: "country", pinyin: "guó" },
  { character: "来", meaning: "come", pinyin: "lái" },
  { character: "到", meaning: "arrive", pinyin: "dào" },
  { character: "时", meaning: "time", pinyin: "shí" },
  { character: "要", meaning: "want", pinyin: "yào" },
  { character: "就", meaning: "just", pinyin: "jiù" },
  { character: "出", meaning: "go out", pinyin: "chū" },
  { character: "会", meaning: "can/will", pinyin: "huì" },
  { character: "可", meaning: "can/may", pinyin: "kě" },
  { character: "也", meaning: "also", pinyin: "yě" },
  { character: "你们", meaning: "you (plural)", pinyin: "nǐmen" },
  { character: "对", meaning: "correct", pinyin: "duì" },
  { character: "生", meaning: "life", pinyin: "shēng" },
  { character: "能", meaning: "ability", pinyin: "néng" },
  { character: "而", meaning: "but/and", pinyin: "ér" },
  { character: "子", meaning: "child", pinyin: "zǐ" },
  { character: "那", meaning: "that", pinyin: "nà" },
  { character: "得", meaning: "must", pinyin: "děi" },
  { character: "于", meaning: "in/at", pinyin: "yú" },
  { character: "着", meaning: "with", pinyin: "zhe" },
  { character: "下", meaning: "down", pinyin: "xià" },
  { character: "自", meaning: "self", pinyin: "zì" },
  { character: "之", meaning: "of", pinyin: "zhī" },
  { character: "年", meaning: "year", pinyin: "nián" },
  { character: "过", meaning: "pass", pinyin: "guò" },
  { character: "发", meaning: "send", pinyin: "fā" },
  { character: "后", meaning: "after", pinyin: "hòu" },
  { character: "作", meaning: "do/make", pinyin: "zuò" },
  { character: "里", meaning: "inside", pinyin: "lǐ" },
  { character: "用", meaning: "use", pinyin: "yòng" },
  { character: "道", meaning: "way", pinyin: "dào" },
];

export default function ChineseCharacterGame() {
  const [index, setIndex] = useState(0);
  const [input, setInput] = useState("");
  const [feedback, setFeedback] = useState("");
  const [showAnswer, setShowAnswer] = useState(false);

  const current = characters[index];

  const handleSubmit = (e) => {
    e.preventDefault();
    const isCorrect = input.trim().toLowerCase() === current.meaning.toLowerCase();
    setFeedback(
      isCorrect
        ? "Correct!"
        : `Incorrect. Correct answer: ${current.meaning} (${current.pinyin})`
    );
    setShowAnswer(true);
  };

  const handleNext = () => {
    setIndex((prev) => (prev + 1) % characters.length);
    setInput("");
    setFeedback("");
    setShowAnswer(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <h1 className="text-2xl font-bold mb-4">Learn Chinese Characters</h1>
      <div className="text-6xl mb-6">{current.character}</div>
      <form onSubmit={handleSubmit} className="flex flex-col items-center">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="border p-2 text-lg rounded mb-2"
          placeholder="What does this character mean?"
        />
        {!showAnswer ? (
          <button
            type="submit"
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Submit
          </button>
        ) : (
          <button
            type="button"
            onClick={handleNext}
            className="bg-green-500 text-white px-4 py-2 rounded"
          >
            Next character
          </button>
        )}
      </form>
      {feedback && <p className="mt-4 text-xl">{feedback}</p>}
    </div>
  );
}
